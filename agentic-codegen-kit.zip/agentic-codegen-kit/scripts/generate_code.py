#!/usr/bin/env python3
"""
SpecKit Code Generator
Reads constitution.md + requirement-spec.md, calls Claude Sonnet API,
generates code and tests, runs tests, fixes failures — loops until 80%+ pass.

Usage:
  python generate_code.py \
    --constitution devin/constitution.md \
    --spec devin/requirement-spec.md \
    --output src/ \
    --tests tests/

Requirements:
  pip install anthropic pytest pytest-json-report

Environment:
  export ANTHROPIC_API_KEY=your_key_here
"""

import argparse
import os
import subprocess
import sys
import json
import re
from pathlib import Path
import anthropic

# ── Config ────────────────────────────────────────────────────────────────────
MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 8000
MAX_ITERATIONS = 5
PASS_THRESHOLD = 0.80   # 80% tests must pass to stop

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))


# ── File helpers ──────────────────────────────────────────────────────────────
def read_file(path: str) -> str:
    with open(path, "r") as f:
        return f.read()


def write_files(file_map: dict):
    """Write generated files to disk. file_map = {relative_path: content}"""
    for rel_path, content in file_map.items():
        full_path = Path(rel_path)
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, "w") as f:
            f.write(content)
        print(f"  ✓ Written: {rel_path}")


def extract_files_from_response(response_text: str) -> dict:
    """
    Parse Claude's response and extract files.
    Expects blocks like:
      ### FILE: src/adapters/kafka_consumer.py
      ```python
      ... code ...
      ```
    """
    file_map = {}
    pattern = r"### FILE:\s*(\S+)\s*\n```[a-z]*\n(.*?)```"
    matches = re.findall(pattern, response_text, re.DOTALL)
    for filepath, content in matches:
        file_map[filepath.strip()] = content.strip()
    return file_map


# ── Test runner ───────────────────────────────────────────────────────────────
def run_tests(test_dir: str) -> tuple[bool, str, float]:
    """
    Run pytest. Returns (all_passed, output, pass_rate).
    """
    result = subprocess.run(
        ["python", "-m", "pytest", test_dir, "-v", "--tb=short",
         "--json-report", "--json-report-file=test_report.json"],
        capture_output=True, text=True
    )
    output = result.stdout + result.stderr

    # Parse pass rate from JSON report
    pass_rate = 0.0
    try:
        with open("test_report.json") as f:
            report = json.load(f)
        total = report["summary"].get("total", 0)
        passed = report["summary"].get("passed", 0)
        pass_rate = passed / total if total > 0 else 0.0
        print(f"\n  Test results: {passed}/{total} passed ({pass_rate*100:.0f}%)")
    except Exception:
        # Fallback: parse from stdout
        match = re.search(r"(\d+) passed", output)
        if match:
            passed = int(match.group(1))
            failed_match = re.search(r"(\d+) failed", output)
            failed = int(failed_match.group(1)) if failed_match else 0
            total = passed + failed
            pass_rate = passed / total if total > 0 else 0.0

    all_passed = result.returncode == 0
    return all_passed, output, pass_rate


# ── Claude API calls ──────────────────────────────────────────────────────────
def generate_code(constitution: str, spec: str, output_dir: str, test_dir: str) -> str:
    """First call: generate implementation + tests from scratch."""
    prompt = f"""
You are an expert software engineer. Use the constitution and requirement spec below
to generate production-ready code and tests.

IMPORTANT — Response format:
- Output each file using this exact format:
  ### FILE: <relative/path/to/file.py>
  ```python
  <file content>
  ```
- Generate ALL implementation files AND test files in one response
- Write tests first (TDD), then implementation
- Follow all rules in the constitution exactly

---
# CONSTITUTION (project-wide standards)
{constitution}

---
# REQUIREMENT SPEC (what to build)
{spec}

---
Generate all files now. Place implementation files under `{output_dir}` and
test files under `{test_dir}`. Include __init__.py files where needed.
"""
    print("\n⏳ Calling Claude API — generating code and tests...")
    response = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text


def fix_code(constitution: str, spec: str, previous_code: str,
             test_output: str, iteration: int) -> str:
    """Subsequent calls: fix failures from test run."""
    prompt = f"""
You are an expert software engineer. Tests are failing. Analyse the failures and fix the code.

IMPORTANT — Response format:
- Output ONLY the files that need to change
- Use the same format: ### FILE: <path> then ```python ... ```
- Do not output files that are already correct

---
# CONSTITUTION (rules to follow)
{constitution}

---
# REQUIREMENT SPEC
{spec}

---
# CURRENT CODE (iteration {iteration})
{previous_code}

---
# TEST FAILURES
{test_output}

---
Fix the failures. Output only changed files.
"""
    print(f"\n⏳ Iteration {iteration} — fixing failures...")
    response = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text


# ── Main loop ─────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="SpecKit Code Generator")
    parser.add_argument("--constitution", required=True, help="Path to constitution.md")
    parser.add_argument("--spec",         required=True, help="Path to requirement-spec.md")
    parser.add_argument("--output",       default="src/",   help="Output dir for src files")
    parser.add_argument("--tests",        default="tests/", help="Output dir for test files")
    args = parser.parse_args()

    # Read inputs
    constitution = read_file(args.constitution)
    spec = read_file(args.spec)

    print("=" * 60)
    print("  SpecKit Code Generator")
    print(f"  Constitution : {args.constitution}")
    print(f"  Spec         : {args.spec}")
    print(f"  Output       : {args.output}")
    print(f"  Tests        : {args.tests}")
    print(f"  Max iters    : {MAX_ITERATIONS}")
    print(f"  Pass target  : {PASS_THRESHOLD*100:.0f}%")
    print("=" * 60)

    # Step 1: Generate initial code + tests
    response = generate_code(constitution, spec, args.output, args.tests)
    all_code = response

    file_map = extract_files_from_response(response)
    if not file_map:
        print("\n❌ No files extracted from API response. Check response format.")
        print(response[:500])
        sys.exit(1)

    print(f"\n📁 Writing {len(file_map)} files...")
    write_files(file_map)

    # Step 2: Test → fix loop
    for iteration in range(1, MAX_ITERATIONS + 1):
        print(f"\n🧪 Running tests (iteration {iteration}/{MAX_ITERATIONS})...")
        all_passed, test_output, pass_rate = run_tests(args.tests)

        if all_passed or pass_rate >= PASS_THRESHOLD:
            print(f"\n✅ Done! Pass rate: {pass_rate*100:.0f}% — target met.")
            print("   Review generated files, then open a PR.")
            break

        if iteration == MAX_ITERATIONS:
            print(f"\n⚠️  Max iterations reached. Pass rate: {pass_rate*100:.0f}%")
            print("   Manual review required for remaining failures.")
            break

        # Fix and re-write
        fix_response = fix_code(constitution, spec, all_code, test_output, iteration)
        all_code += "\n\n" + fix_response

        fixed_files = extract_files_from_response(fix_response)
        if fixed_files:
            print(f"  📁 Updating {len(fixed_files)} file(s)...")
            write_files(fixed_files)
        else:
            print("  ⚠️  No file changes extracted from fix response.")

    print("\n" + "=" * 60)
    print("  SpecKit complete. Review src/ and tests/ before committing.")
    print("=" * 60)


if __name__ == "__main__":
    main()
